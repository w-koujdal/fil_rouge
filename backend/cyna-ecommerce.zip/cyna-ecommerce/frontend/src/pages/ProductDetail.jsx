import { useParams } from "react-router-dom";
import produits from "../mock/mockData";

export default function ProductDetail() {
  const { id } = useParams();
  const produit = produits.find(p => p.id === parseInt(id));

  if (!produit) return <div>Produit introuvable</div>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">{produit.nom}</h1>
      <img src={produit.image} alt={produit.nom} className="w-64 h-64 object-cover mb-4" />
      <p className="text-gray-700 mb-2">{produit.description}</p>
      <p className="text-xl font-semibold">{produit.prix} €</p>
    </div>
  );
}
