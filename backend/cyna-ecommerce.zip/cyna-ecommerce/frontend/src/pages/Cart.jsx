import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";

export default function Cart() {
  const [panier, setPanier] = useState([]);

  useEffect(() => {
    const data = localStorage.getItem("panier");
    if (data) setPanier(JSON.parse(data));
  }, []);

  const supprimerProduit = (id) => {
    const nouveauPanier = panier.filter(p => p.id !== id);
    setPanier(nouveauPanier);
    localStorage.setItem("panier", JSON.stringify(nouveauPanier));
  };

  const total = panier.reduce((acc, prod) => acc + prod.prix, 0);
  const token = localStorage.getItem("token");

  if (!token) {
    return <Navigate to="/login" />;
  }

  if (panier.length === 0) {
    return <div className="p-6">Votre panier est vide.</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Votre panier</h1>
      <ul className="space-y-4">
        {panier.map(prod => (
          <li key={prod.id} className="border p-4 rounded flex justify-between items-center">
            <div>
              <p className="font-semibold">{prod.nom}</p>
              <p>{prod.prix} €</p>
            </div>
            <button
              onClick={() => supprimerProduit(prod.id)}
              className="text-red-600 hover:underline"
            >
              Supprimer
            </button>
          </li>
        ))}
      </ul>
      <div className="mt-6 text-right font-bold text-lg">
        Total : {total.toFixed(2)} €
      </div>
    </div>
  );
}
