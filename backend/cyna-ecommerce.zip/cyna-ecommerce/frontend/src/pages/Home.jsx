import produits from "../mock/mockData";
import ProductCard from "../components/ProductCard";
import { Navigate } from "react-router-dom";

export default function Home() {
  const token = localStorage.getItem("token");
  if (!token) return <Navigate to="/login" />;

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Catalogue</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {produits.map(prod => (
          <ProductCard key={prod.id} produit={prod} />
        ))}
      </div>
    </div>
  );
}
