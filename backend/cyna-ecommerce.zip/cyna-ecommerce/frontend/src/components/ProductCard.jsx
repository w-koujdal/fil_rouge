import { Link } from "react-router-dom";

export default function ProductCard({ produit }) {
  const ajouterAuPanier = () => {
    const panier = JSON.parse(localStorage.getItem("panier")) || [];
    const existe = panier.find(p => p.id === produit.id);
    if (!existe) {
      panier.push(produit);
      localStorage.setItem("panier", JSON.stringify(panier));
      alert("Produit ajouté au panier !");
    } else {
      alert("Ce produit est déjà dans le panier.");
    }
  };

  return (
    <div className="border p-4 rounded shadow hover:shadow-lg">
      <img src={produit.image} alt={produit.nom} className="mb-2 w-full h-32 object-cover" />
      <h2 className="text-lg font-semibold">{produit.nom}</h2>
      <p className="text-sm text-gray-600">{produit.prix} €</p>
      <div className="flex justify-between mt-2">
        <Link to={`/produit/${produit.id}`} className="text-blue-500 hover:underline">
          Voir
        </Link>
        <button
          onClick={ajouterAuPanier}
          className="text-green-600 hover:underline"
        >
          Ajouter
        </button>
      </div>
    </div>
  );
}
