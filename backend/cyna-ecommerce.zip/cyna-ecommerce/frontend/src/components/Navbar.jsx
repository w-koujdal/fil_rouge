import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("panier"); // Réinitialiser le panier
    navigate("/login");
  };

  return (
    <nav className="bg-gray-800 text-white px-6 py-4 flex justify-between items-center shadow">
      <div className="text-xl font-bold">
        <Link to="/">CynaShop</Link>
      </div>
      <div className="flex items-center space-x-6">
        <Link to="/" className="hover:underline">Accueil</Link>
        <Link to="/panier" className="hover:underline">Panier</Link>

        {token ? (
          <button
            onClick={handleLogout}
            className="text-red-400 hover:text-red-300 transition"
            title="Se déconnecter"
          >
            Déconnexion
          </button>
        ) : (
          <Link to="/login" className="hover:underline">
            Connexion
          </Link>
        )}
      </div>
    </nav>
  );
}
