import { BrowserRouter } from "react-router-dom";
import RouterApp from "./router/Router";
import Navbar from "./components/Navbar";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <RouterApp />
    </BrowserRouter>
  );
}

export default App;
