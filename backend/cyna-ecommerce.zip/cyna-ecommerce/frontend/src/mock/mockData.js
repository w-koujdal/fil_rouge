const produits = [
  {
    id: 1,
    nom: "Clavier mécanique RGB",
    prix: 79.99,
    image: "https://via.placeholder.com/150",
    description: "Clavier rétroéclairé pour gamers exigeants."
  },
  {
    id: 2,
    nom: "Souris sans fil",
    prix: 49.99,
    image: "https://via.placeholder.com/150",
    description: "Souris ergonomique, autonomie 30 jours."
  },
  {
    id: 3,
    nom: "Écran 24 pouces",
    prix: 129.99,
    image: "https://via.placeholder.com/150",
    description: "Écran Full HD avec taux de rafraîchissement 144Hz."
  }
];

export default produits;
