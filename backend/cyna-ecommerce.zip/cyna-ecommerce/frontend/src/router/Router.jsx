import { Routes, Route } from "react-router-dom";
import Home from "../pages/Home";
import ProductDetail from "../pages/ProductDetail";
import Cart from "../pages/Cart";
import Login from "../pages/Login";

export default function RouterApp() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/produit/:id" element={<ProductDetail />} />
      <Route path="/panier" element={<Cart />} />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<div className="p-6 text-red-600">Erreur 404 – Page non trouvée</div>} />
    </Routes>
  );
}
