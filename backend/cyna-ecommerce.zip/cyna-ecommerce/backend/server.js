const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

// Simule un utilisateur
const FAKE_USER = {
  email: "test@mail.com",
  password: "1234",
  token: "faketoken123"
};

// Route de connexion
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  if (email === FAKE_USER.email && password === FAKE_USER.password) {
    return res.json({ token: FAKE_USER.token });
  } else {
    return res.status(401).json({ error: "Identifiants invalides" });
  }
});

app.listen(port, () => {
  console.log(`🔐 API Auth en ligne sur http://localhost:${port}`);
});
