const express = require("express");
const cors = require("cors");
const app = express();
const db = require("./models");

// ✅ D'abord, les middlewares globaux
app.use(cors());
app.use(express.json());

// 🧪 Middleware temporaire de simulation d'utilisateur (avant les routes !)
app.use((req, res, next) => {
  req.user = { nom: 'Walid', role: 'admin' }; // ou 'client'
  next();
});

// ✅ Ensuite les routes
const routeProduits = require("./routes/produits");
const paiementRoute = require('./routes/paiement');

app.use("/api/produits", routeProduits);
app.use("/api/paiement", paiementRoute);

// 🔁 Sync + lancement du serveur
db.sequelize.sync().then(() => {
  app.listen(3001, () => {
    console.log("✅ API disponible sur http://localhost:3001");
  });
});
