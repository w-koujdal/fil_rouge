module.exports = (sequelize, DataTypes) => {
  const Produit = sequelize.define("Produit", {
    id_produit: {
      type: DataTypes.BIGINT.UNSIGNED,
      primaryKey: true,
      autoIncrement: true
    },
    nom: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    prix: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true
    },
    disponibilite: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true
    },
    date_creation: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW
    }
  }, {
    tableName: "produits",
    timestamps: false
  });

  return Produit;
};
