const { Sequelize, DataTypes } = require("sequelize");
const sequelize = new Sequelize("cyna_saas_db", "root", "MYSQL", {
  host: "localhost",
  dialect: "mysql",
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.Produit = require("./produit")(sequelize, DataTypes); // <-- important !

module.exports = db;
