const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
  const body = req.body;

  if (!body || !body.id_produit || !body.montant) {
    return res.status(400).json({ message: "Champs manquants ou invalides" });
  }

  const { id_produit, montant } = body;

  const token = Math.random().toString(36).substring(2, 15);

  res.status(200).json({
    success: true,
    message: "Paiement simulé avec succès.",
    transaction_token: token,
    id_produit,
    montant,
    date: new Date()
  });
});

module.exports = router;
