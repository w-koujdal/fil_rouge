const express = require('express');
const router = express.Router();
const db = require('../models');
const Produit = db.Produit;

// 👉 Middleware temporaire (à remplacer si besoin)
const isAdmin = require('../../src/middlewares/isAdmin');

// ✅ GET : accessible à tous (produits disponibles uniquement)
router.get('/', async (req, res) => {
  try {
    const produits = await Produit.findAll({ where: { disponibilite: true } });
    res.json(produits);
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur', erreur: err.message });
  }
});

// ✅ POST : création (protégé)
router.post('/', isAdmin, async (req, res) => {
  try {
    const { nom, description, prix, disponibilite } = req.body;
    if (!nom || prix == null) return res.status(400).json({ message: 'Champs manquants' });

    const nouveauProduit = await Produit.create({
      nom,
      description: description || '',
      prix,
      disponibilite: typeof disponibilite === 'boolean' ? disponibilite : true,
      date_creation: new Date()
    });

    res.status(201).json({ message: 'Produit créé', produit: nouveauProduit });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur', erreur: err.message });
  }
});

// ✅ PUT : modification (protégé)
router.put('/:id', isAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const produit = await Produit.findByPk(id);
    if (!produit) return res.status(404).json({ message: 'Produit non trouvé' });

    const { nom, description, prix, disponibilite } = req.body;

   await produit.update({
  nom: nom !== undefined ? nom : produit.nom,
  description: description !== undefined ? description : produit.description,
  prix: prix !== undefined ? prix : produit.prix,
  disponibilite: disponibilite !== undefined ? disponibilite : produit.disponibilite,
});



    res.json({ message: 'Produit modifié', produit });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur', erreur: err.message });
  }
});

// ✅ DELETE : suppression (protégé)
router.delete('/:id', isAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const produit = await Produit.findByPk(id);
    if (!produit) return res.status(404).json({ message: 'Produit non trouvé' });

    await produit.destroy();
    res.json({ message: 'Produit supprimé' });
  } catch (err) {
    res.status(500).json({ message: 'Erreur serveur', erreur: err.message });
  }
});

module.exports = router;
