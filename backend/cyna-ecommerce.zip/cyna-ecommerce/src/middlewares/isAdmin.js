module.exports = function isAdmin(req, res, next) {
  // Vérifie si un utilisateur est connecté et admin
  if (!req.user || req.user.role !== 'admin') {
    console.warn('Tentative d’accès refusée — utilisateur non admin');
    return res.status(403).json({ message: 'Accès réservé aux administrateurs' });
  }
  
  next(); // Autorise l’accès si admin
};
