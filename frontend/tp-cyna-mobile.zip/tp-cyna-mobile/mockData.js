const mockProduits = [
  {
    id: 1,
    nom: "Module Devis & Facturation",
    description: "Générez facilement vos devis, factures et relances. Suivi des paiements en temps réel.",
    fonctionnalites: "- Création de devis & factures PDF\n- Rappels automatiques\n- Historique client",
    cible: "Artisans, indépendants, PME de service",
    prix: 19.99,
    disponibilite: "Disponible immédiatement",
  },
  {
    id: 2,
    nom: "Module Gestion de Rendez-vous",
    description: "Organisez votre planning avec un agenda connecté. Notifications clients intégrées.",
    fonctionnalites: "- Calendrier partagé\n- SMS/email de rappel\n- Synchronisation Google",
    cible: "Coachs, cabinets, métiers du soin",
    prix: 14.99,
    disponibilite: "Bêta publique",
  },
  {
    id: 3,
    nom: "Module CRM Simplifié",
    description: "Centralisez les informations clients et suivez vos opportunités commerciales.",
    fonctionnalites: "- Fiches clients détaillées\n- Historique des échanges\n- Segmentation & relances",
    cible: "TPE, équipes commerciales",
    prix: 24.99,
    disponibilite: "Disponible avec support 7j/7",
  },
  {
    id: 4,
    nom: "Module Tableau de Bord",
    description: "Suivez vos indicateurs clés (CA, RDV, productivité) en un coup d’œil.",
    fonctionnalites: "- Graphiques interactifs\n- Exports Excel/CSV\n- Alertes personnalisées",
    cible: "Chefs d'entreprise, indépendants",
    prix: 9.99,
    disponibilite: "Disponible en version mobile & web",
  },
  {
    id: 5,
    nom: "Module Espace Client",
    description: "Offrez un accès sécurisé à vos clients pour consulter documents et payer en ligne.",
    fonctionnalites: "- Accès documents\n- Paiement en ligne\n- Support client intégré",
    cible: "Entreprises orientées B2B",
    prix: 12.49,
    disponibilite: "Disponible (version stable)",
  }
];

export default mockProduits;
