import React from 'react';
import { View, Text, FlatList, Button, TouchableOpacity, StyleSheet } from 'react-native';
import mockProducts from '../mockProducts';

export default function ProductListScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Liste des Produits</Text>
      <FlatList
        data={mockProducts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('ProductDetail', { product: item })}
          >
            <Text style={styles.name}>{item.nom}</Text>
            <Text>{item.prix} €</Text>
          </TouchableOpacity>
        )}
      />
      <Button title="Ajouter un produit" onPress={() => navigation.navigate('ProductForm')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 15 },
  item: { padding: 15, borderBottomWidth: 1, borderColor: '#ccc' },
  name: { fontSize: 18 },
});
