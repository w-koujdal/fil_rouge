const mockProducts = [
  { id: 1, nom: 'Produit A', description: 'Description du produit A', prix: 10.99 },
  { id: 2, nom: 'Produit B', description: 'Description du produit B', prix: 20.50 },
  { id: 3, nom: 'Produit C', description: 'Description du produit C', prix: 15.75 },
];

export default mockProducts;
