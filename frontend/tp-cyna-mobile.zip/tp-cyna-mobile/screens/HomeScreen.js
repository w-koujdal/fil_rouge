import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function HomeScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Header / Branding */}
      <Text style={styles.brand}>CYNA</Text>

      {/* Sous-titre accrocheur */}
      <Text style={styles.subtitle}>
        Modules SaaS pour les artisans modernes
      </Text>

      {/* Image ou illustration */}
      <Image
        source={require('../assets/home-illustration.png')} // 🔁 À adapter selon ton projet
        style={styles.image}
        resizeMode="contain"
      />

      {/* Bouton d'accès aux modules */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('ProductList')}
      >
        <Text style={styles.buttonText}>Accéder aux modules</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F9FC',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  brand: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#0074D9',
    marginBottom: 10,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 16,
    color: '#4A4A4A',
    textAlign: 'center',
    marginBottom: 20,
  },
  image: {
    width: '100%',
    height: 200,
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#0074D9',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 12,
    elevation: 2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});
