// PaiementScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet, Alert } from 'react-native';

export default function PaiementScreen({ route, navigation }) {
  const produit = route.params?.produit;

  const handlePaiement = async () => {
    try {
      const res = await fetch("http://192.168.1.169:3001/api/paiement", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id_produit: produit.id_produit,
          montant: produit.prix
        })
      });

      const data = await res.json();

      if (data.success) {
        Alert.alert("✅ Paiement réussi", `Token : ${data.transaction_token}`);
        navigation.navigate("ProductList");
      } else {
        Alert.alert("Erreur", data.message || "Paiement échoué.");
      }
    } catch (err) {
      Alert.alert("Erreur", err.message || "Impossible de contacter le serveur.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Paiement simulé</Text>
      <Text style={styles.text}>Module : {produit.nom}</Text>
      <Text style={styles.text}>Prix : {produit.prix} €</Text>
      <Button title="Confirmer le paiement" onPress={handlePaiement} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  text: { fontSize: 18, marginBottom: 10 }
});
