import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function ProductFormScreen({ route, navigation }) {
  const produitInitial = route.params?.produit || null;

  const [nom, setNom] = useState('');
  const [description, setDescription] = useState('');
  const [prix, setPrix] = useState('');
  const [disponibilite, setDisponibilite] = useState('1'); // Valeur par défaut : dispo

  useEffect(() => {
    if (produitInitial) {
      setNom(produitInitial.nom || '');
      setDescription(produitInitial.description || '');
      setPrix(String(produitInitial.prix || ''));
      setDisponibilite(
        produitInitial.disponibilite === false ? '0' : '1'
      );
    }
  }, [produitInitial]);

  const handleSubmit = async () => {
    if (!nom || !prix) {
      Alert.alert("Erreur", "Le nom et le prix sont obligatoires.");
      return;
    }

    // Payload dynamique
    const payload = {
      nom,
      description,
      prix: parseFloat(prix)
    };

    if (produitInitial || disponibilite !== '') {
      payload.disponibilite = String(disponibilite) === '1';
    }

    try {
      const method = produitInitial ? 'PUT' : 'POST';
      const id = produitInitial?.id_produit;

      if (produitInitial && !id) {
        Alert.alert("Erreur", "ID du produit manquant pour la modification.");
        return;
      }

      const url = produitInitial
        ? `http://192.168.1.169:3001/api/produits/${id}`
        : 'http://192.168.1.169:3001/api/produits';

      console.log("🔍 URL de la requête :", url);
      console.log("📦 Payload envoyé :", payload);

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const contentType = response.headers.get("content-type");

      let data;
      if (contentType && contentType.includes("application/json")) {
        data = await response.json();
      } else {
        const text = await response.text();
        throw new Error(`Réponse non JSON : ${text}`);
      }

      if (response.ok) {
        Alert.alert("Succès", produitInitial ? "Produit modifié." : "Produit ajouté.");
        navigation.navigate('ProductList');
      } else {
        Alert.alert("Erreur", data.message || "Erreur inconnue.");
      }
    } catch (err) {
      console.error("Erreur requête :", err);
      Alert.alert("Erreur", err.message || "Impossible de contacter le serveur.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        {produitInitial ? "Modifier un module" : "Ajouter un module SaaS"}
      </Text>

      <TextInput
        placeholder="Nom du module"
        value={nom}
        onChangeText={setNom}
        style={styles.input}
      />
      <TextInput
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        style={[styles.input, { height: 100 }]}
        multiline
      />
      <TextInput
        placeholder="Prix (€ / mois)"
        value={prix}
        onChangeText={setPrix}
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        placeholder="Disponibilité (1 = dispo, 0 = non)"
        value={disponibilite}
        onChangeText={setDisponibilite}
        keyboardType="numeric"
        style={styles.input}
      />
      <Button
        title={produitInitial ? "Enregistrer les modifications" : "Ajouter le produit"}
        onPress={handleSubmit}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 15,
    padding: 10,
    borderRadius: 5
  }
});
