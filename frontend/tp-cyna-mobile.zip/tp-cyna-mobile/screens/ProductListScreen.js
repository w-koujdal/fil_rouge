import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function ProductListScreen() {
  const [produits, setProduits] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    fetch('http://192.168.1.169:3001/api/produits')
      .then(res => res.json())
      .then(data => setProduits(data))
      .catch(err => console.error('❌ Erreur chargement produits :', err));
  }, []);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate('ProductDetail', { produit: item })}
    >
      <Image
        source={require('../assets/module-icon.png')}
        style={styles.image}
      />
      <View style={styles.info}>
        <Text style={styles.nom}>{item.nom}</Text>
        <Text style={styles.prix}>{item.prix} € / mois</Text>
        <Text style={styles.dispo}>
          {item.disponibilite ? '✅ Disponible' : '⛔ Indisponible'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nos modules SaaS</Text>
      <FlatList
        data={produits}
        keyExtractor={(item) => item.id_produit.toString()}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 80 }}
      />
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('ProductForm')}
      >
        <Text style={styles.addText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9f9f9', paddingHorizontal: 15, paddingTop: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  card: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 4
  },
  image: { width: 50, height: 50, marginRight: 15 },
  info: { flex: 1 },
  nom: { fontSize: 18, fontWeight: 'bold' },
  prix: { fontSize: 16, color: '#555', marginTop: 4 },
  dispo: { marginTop: 4, fontSize: 14, color: '#888' },
  addButton: {
    position: 'absolute',
    bottom: 25,
    right: 25,
    backgroundColor: '#007BFF',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 3 },
    elevation: 6
  },
  addText: { fontSize: 30, color: '#fff' }
});
