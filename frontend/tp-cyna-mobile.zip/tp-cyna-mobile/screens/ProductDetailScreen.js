import React from 'react';
import { View, Text, Image, Button, StyleSheet, Alert } from 'react-native';
import { useAuth } from '../context/AuthContext'; // Assure-toi que ce chemin est correct

export default function ProductDetailScreen({ route, navigation }) {
  const { user } = useAuth();
  const produit = route.params?.produit;

  if (!produit) return <Text>Produit introuvable.</Text>;

  const handleDelete = () => {
    Alert.alert(
      "Confirmation",
      "Supprimer ce produit ?",
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Supprimer",
          style: "destructive",
          onPress: async () => {
            try {
              const response = await fetch(`http://192.168.1.169:3001/api/produits/${produit.id_produit}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
              });
              if (response.ok) {
                Alert.alert("Succès", "Produit supprimé.");
                navigation.navigate("ProductList");
              } else {
                const data = await response.json();
                Alert.alert("Erreur", data.message || "Échec suppression.");
              }
            } catch (err) {
              Alert.alert("Erreur", "Impossible de contacter le serveur.");
            }
          },
        },
      ]
    );
  };

  const handlePaiement = async () => {
    try {
      const response = await fetch("http://192.168.1.169:3001/api/paiement", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id_produit: produit.id_produit,
          montant: produit.prix
        })
      });

      const data = await response.json();

      if (data.success) {
        Alert.alert("✅ Paiement simulé", `Transaction #${data.transaction_token}`);
      } else {
        Alert.alert("❌ Échec", data.message || "Problème lors du paiement");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("⚠️ Erreur", "Impossible de contacter le serveur.");
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/product-saas.png')} // Remplace avec une illustration adaptée
        style={styles.image}
        resizeMode="contain"
      />

      <Text style={styles.title}>{produit.nom}</Text>
      <Text style={styles.description}>{produit.description}</Text>
      <Text style={styles.prix}>{produit.prix} € / mois</Text>

      <Text style={[styles.dispo, {
        color: produit.disponibilite ? 'green' : 'red'
      }]}> {produit.disponibilite ? '✅ Disponible' : '❌ Indisponible'} </Text>

      {user?.role === 'admin' && (
        <View style={styles.actions}>
          <Button title="Modifier" onPress={() => navigation.navigate("ProductForm", { produit })} />
          <View style={{ marginVertical: 10 }} />
          <Button title="Supprimer" color="red" onPress={handleDelete} />
        </View>
      )}

      <Button title="Simuler un paiement" onPress={handlePaiement} />

      <View style={{ marginTop: 30 }}>
        <Button title="Retour à la liste" onPress={() => navigation.goBack()} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff'
  },
  image: {
    width: '100%',
    height: 200,
    marginBottom: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10
  },
  description: {
    fontSize: 16,
    color: '#555',
    lineHeight: 22,
    marginBottom: 10
  },
  prix: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007BFF',
    marginBottom: 10
  },
  dispo: {
    fontSize: 16,
    marginBottom: 20
  },
  actions: {
    marginVertical: 20
  }
});
