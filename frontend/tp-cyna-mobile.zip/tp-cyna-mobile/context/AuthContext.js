import React, { createContext, useState, useContext } from 'react';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // utilisateur pas connecté au départ

  const login = async (email, password) => {
    // 🔐 Authentification simulée (à remplacer plus tard par appel API)
    if (email === 'admin@cyna.fr' && password === 'admin') {
      const utilisateur = { nom: 'Walid', role: 'admin' };
      setUser(utilisateur);
      return { success: true, user: utilisateur };
    } else if (email === 'client@cyna.fr' && password === 'client') {
      const utilisateur = { nom: 'Client test', role: 'client' };
      setUser(utilisateur);
      return { success: true, user: utilisateur };
    } else {
      return { success: false, error: 'Identifiants invalides' };
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// ✅ Hook pour accéder facilement au contexte
export function useAuth() {
  return useContext(AuthContext);
}
